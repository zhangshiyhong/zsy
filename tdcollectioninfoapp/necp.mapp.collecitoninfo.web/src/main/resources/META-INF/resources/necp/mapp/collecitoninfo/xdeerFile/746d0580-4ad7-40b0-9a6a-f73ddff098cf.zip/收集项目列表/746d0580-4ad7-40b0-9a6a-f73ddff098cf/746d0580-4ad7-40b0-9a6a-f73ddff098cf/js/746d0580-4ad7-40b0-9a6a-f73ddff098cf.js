require(["ecp.service", "ecp.utils.render", 'ecp.model'], function (ecpService, renderUtil, ecpModel) {
    "use strict";

    // 日志对象
    var log = ecpService.Log;

    /**
     * 声明函数对象.
     */
    var PageController = function () {
        //初始化页面
        this.initPage();
    }

    /**
     * 通过原型定义相关方法，比如渲染、赋值等等.
     */
    PageController.prototype = {
        /**
         * 初始化页面.
         */
        initPage: function () {
            //todo
            var winH = $(window).height();

            $(".gridRect").css('height', winH - 320);
        },
        /**
         * 渲染.
         * 基础控件渲染和统一渲染页面控件
         */
        render: function () {
            //渲染页面控件
            renderUtil.pageRender($.proxy(this.afterRender, this));
        },
        /**
         * 渲染后.
         */
        afterRender: function (map) {
            if (map) {
                for (var i in map) {
                    this[i] = map[i];
                }
            }
            //绑定事件
            this.bindEvent();
            this.getPageDataModel();
        },

        /**
         * 绑定事件.
         */
        bindEvent: function () {
//@bindEvent//***controlScript***
            //ctrlInfo_d2b9280b-8acf-4cd7-93a6-34bca09c72a4_普通查询_4c08b754e9988054a1b71eef31733458_ctrlInfo
            //***controlScript***
            //***controlScript***
            //ctrlInfo_114c9364-15f6-4439-8bf5-b884fe695812_页面工具栏_11c83b6d558337bb810f592c1d29cfe6_ctrlInfo

            //***controlScript***
//ctrlInfo_root_com_24466139829481ec3917ebcec7656599__tableEvent_ctrlInfo
var grid_root = this["root"]
var me = this
if (grid_root){var gridData_root = grid_root.value();
var pageSize_root= grid_root.getPageSize();
grid_root.setTotalRecord(gridData_root.length, false);
grid_root.value(gridData_root.slice(0,pageSize_root));
grid_root.bind("onPageChanged",function(pageCount, pageSize, pageIndex){
var data = gridData_root.slice(pageSize * (pageIndex-1),pageSize + pageSize * (pageIndex-1));
grid_root.value(data);
});
me.afterLoadDataTasks = me.afterLoadDataTasks || [];
me.afterLoadDataTasks.push(function(){
grid_root.value(gridData_root.slice(0,pageSize_root));
})
}
//ctrlInfo_root_com_24466139829481ec3917ebcec7656599__tableEvent_ctrlInfo
//@bindEvent
},

        /**
         * 获取页面数据模型.
         */
        getPageDataModel: function () {









            
			//@getPageDataModel
			//@getPageDataModel 
  









        },

        /**
         * 绑定数据源.
         */
        bindDataSource: function () {
            var dataModelItems = this.pageDataModel.items || [];
            var dataModelItem = dataModelItems[0];
            this.dataSource = new ecpModel.DataSource();
            this.dataSource.dataModel = dataModelItem;
            this.dataSource.bind($("body"));
        }
    }
    /**
     * 开始执行.
     */
    var controller = new PageController();
    controller.render();
})